<!DOCTYPE html>
<html lang="en">
<head>
  <title>&star;&lt;Nitro~Haven&gt;&star;</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Chargement des feuilles de styles depuis des librairies externes et des polices-->
  <link href="https://fonts.googleapis.com/css?family=Bungee+Shade|Caveat|Megrim|Fondamento|Press+Start+2P" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
  <style>
    /* L'icône toggler restait visible pour n'importe quels dimensions de la fenêtre donc... */
    @media screen and (min-width: 768px){
      .navbar-toggler{
        display: none;
      }
    }
    
    body{
      /* L'une des polices que j'ai importé depuis Google Fonts */
      font-family: "Fondamento", cursive;
      /*Au cas où, le "bg" ne couvre pas tout l'écran*/
      background-color: black;
    }
    .view{
      /* Image du décor */
      background-image: url('img/cubes.gif');
      /* Centrer et positionner correctement l'image sans répétition*/
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    }

    html, body, header, .view{
      /* Remplis la totalité de l'écran */
      height: 100%;
      height: 100%;
    }

    @media (min-width: 768px){
      .navbar:not(.top-nav-collapse){
        background: transparent !important;
      }
    }

    @media (max-width: 1200px){
      .container{
        display: none;
      }
      .fullscreen{
        visibility: visible;
        cursor: pointer;
        text-decoration: underline;
        text-align: center;
      }
    }

    @media (min-width: 1200px){
      .fullscreen{
        visibility: hidden;
      }
    }
    
    .top-nav-collapse{
      background-color: #78909c !important;
    }
    /*Transparence de la navbar*/
    .navbar:not(.top-nav-collapse){
      background: transparent !important;
    }

    h1{
      letter-spacing: 8px;
    }

    h5{
      letter-spacing: 3px;
    }

    .hr-light{
      border-top: 3px solid #fff;
      width: 80px;
    }

    .container{
      color: white;
    }

    /*Texte blanc entouré de noir*/
    .stroke{
        color: black;
        text-shadow:
        -1px -1px 0 white,
        1px -1px 0 white,
        -1px 1px 0 white,
        1px 1px 0 white;  
    }

    .col{
        border: 1px solid white;
        width: 158px;
    }

    .row .glyphicon{
        font-size: 75px;
    }

    .gr{
        height: 102px;
    }

    .glyphicon-copyright-mark, .fa, .copy{
      float: right;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: red;
    }

    .fa{
      float: left;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: red;
    }

    .glyphicon-copyright-mark{
      color: white;
      font-size: 15px;
      padding-top: 15px;
      text-align: center;
    }

    .copyr{
      color: white;
      font-size: 15px;
      padding-top: 5px;
      text-align: center;
    }
  </style>
</head>
<body>
  <header>
  <!-- Mes choix personnels (fixed-top pour que la navbar reste collée en haut -->
  <div class="view">
  <nav class="navbar navbar-expand-lg navbar-inverse bg-inverse navbar-toggleable-lg scrolling-navbar fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" style="color: red" href="index.php">&star;&lt;Nitro~Haven&gt;&star;</a>&nbsp;
        <!-- Création du bouton pour le basculement du menu -->
        <a class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <!-- Le "navbar-toggler-icon" ne s'affichant pas, j'ai rajouté une icône hamburger (Bootstrap) -->
          <span style="float: right; font-size: 25px; padding: 3px; color: red;" class="glyphicon glyphicon-menu-hamburger"></span>
        </a>
      </div>
      <!-- J'ai créé des listes désordonnées pour le style des liens -->
      <ul class="nav navbar-nav collapse navbar-collapse" id="navbarNav">
        <li><a href="index.php">Accueil</a></li>
        <li  class="active"><a href="products.php">Produits</a></li>
        <li><a href="gallery.php">Galeries</a></li>
        <li><a href="contact.php">Nous contacter</a></li>
      </ul>
      <hr>
    </div>
  </nav>
    <!-- Alignement de la page et de ses éléments "enfants" -->
  <div class="mask rgba-black-light d-flex justify-content-center align-items-center">
    <!-- Contenu -->
    <div class="container" style="vertical-align: middle; text-align: center; position:relative;">
      <div class="row align-items-center table table-hover" style="width: 1200px; display: table-cell; vertical-align: middle;">
        <div>
              <div class="row align-items-center">
                <div class = "col col-md-2" style="border-left: none; border-top: none;">&nbsp;</div>
                <div class = "col col-md-2">Capacité de Stockage</div>
                <div class = "col col-md-2" style="width: 143px;">Tailles des fichiers</div>
                <div class = "col col-md-2" style="width: 160px;">Édition Collaborative</div>
                <div class = "col col-md-2" style="width: 227px;">Intégré au système d'exploitation</div>
                <div class = "col col-md-2" style="width: 178px;">Gestions de permissions</div>
                <div class = "col col-md-2" style="width: 140px;">Tarifs</div>
              </div>
        </div>
        <div class="row align-items-center">
              <div class = "col col-md-2 gr"><img src = "img/dropbox.png " style = "width : 100px"> </div>
              <div class = "col col-md-2 gr">1000 Go</div>
              <div class = "col col-md-2 gr" style="width: 143px;">Pas de limite via l'application de bureau - 20 Go via le site</div>
              <div class = "col col-md-2 gr" style="width: 160px;"><div class = "glyphicon glyphicon-remove" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 227px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 178px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 140px;">8.25€ par utilisateurs/mois</div>
        </div>
        <div class="row align-items-center">
              <div class = "col col-md-2 gr"><img src="img/drive.png"style = "width : 100px"></div>
              <div class = "col col-md-2 gr">30 Go</div>
              <div class = "col col-md-2 gr" style="width: 143px;">Textes : 50Mo <br>Présentation : 100Mo <br>Autres fichiers jusqu'à 5 To</div>
              <div class = "col col-md-2 gr" style="width: 160px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 227px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 178px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 140px;">4€ par utilisateurs/mois</div>
        </div>
        <div class="row align-items-center">
              <div class = "col col-md-2 gr"><img src="img/onedrive.png"style = "width : 100px"></div>
              <div class = "col col-md-2 gr">1000 Go<br> par utilisateurs</div>
              <div class = "col col-md-2 gr" style="width: 143px;">10 Go</div>
              <div class = "col col-md-2 gr" style="width: 160px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 227px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 178px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 140px;">4.20€ par utilisateurs/mois</div>
        </div>
        <div class="row align-items-center">
              <div class = "col col-md-2 gr"><img src="img/box.png"style = "width : 100px"></div>
              <div class = "col col-md-2 gr">100 Go</div>
              <div class = "col col-md-2 gr" style="width: 143px;">2 Go</div>
              <div class = "col col-md-2 gr" style="width: 160px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 227px;"><div class = "glyphicon glyphicon-remove" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 178px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 140px;">4€ par utilisateurs/mois<br>(min 3 utilisateurs max 10)</div>
        </div>
        <div class="row align-items-center">
              <div class = "col col-md-2 gr"><img src="img/pcloud.png"style = "width : 100px"></div>
              <div class = "col col-md-2 gr">500 Go</div>
              <div class = "col col-md-2 gr" style="width: 143px;">Aucune restriction</div>
              <div class = "col col-md-2 gr" style="width: 160px;"><div class = "glyphicon glyphicon-remove" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 227px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 178px;"><div class = "glyphicon glyphicon-ok" style = "width : 70px"></div></div>
              <div class = "col col-md-2 gr" style="width: 140px;">3.99€ par utilisateurs/mois</div>
        </div>
      </div>
    </div>
    <div class="fullscreen" onclick="Open()" style="color: gold">Plein écran afin de voir le tableau &star;</div>
    <div class="footer fixed-bottom">
      <a class="navbar-brand fixed-bottom" style="color: red" href="contact.php">Nous Contacter</a>&nbsp;
      <a href="https://www.facebook.com/FacebookFrance/" class="fa fa-facebook"></a>
      <a href="https://twitter.com/TwitterDev?ref_src=twsrc%5Etfw" class="fa fa-twitter"></a>
      <a href="https://plus.google.com/+Chrome" class="fa fa-google-plus"></a>
      <span class="glyphicon glyphicon-copyright-mark" style="visibility: hidden;"></span>
      <span class="glyphicon glyphicon-copyright-mark"></span>
      <div class="copy" style="height: 15px;">
        <span class="copyr">Nitro Haven</span>
      </div>
    </div>
  </header>
</body>
</html>
<script>// Plein écran
  var elem = document.documentElement;
  function Open() {
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { /* Firefox */
      elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera */
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { /* IE/Edge */
      elem.msRequestFullscreen();
    }
  }
</script>