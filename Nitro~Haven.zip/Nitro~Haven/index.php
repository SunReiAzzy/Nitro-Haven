<!DOCTYPE html>
<html lang="en">
<head>
  <title>&star;&lt;Nitro~Haven&gt;&star;</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Chargement des feuilles de styles depuis des librairies externes de styles, d'icônes et de polices-->
  <link href="https://fonts.googleapis.com/css?family=Bungee+Shade|Caveat|Megrim|Fondamento|Press+Start+2P" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
  <style>
    /* L'icône toggler restait visible pour n'importe quels dimensions de la fenêtre donc... */
    @media screen and (min-width: 768px){
      .navbar-toggler{
        display: none;
      }
    }
    
    body{
      /* L'une des polices que j'ai importé depuis Google Fonts */
      font-family: "Fondamento", cursive;
      /*Au cas où, le "bg" ne couvre pas tout l'écran*/
      background-image: url("img/tech.jpg");
    }
    .view{
      /* Image du décor */
      background-image: url('img/cubes.gif');
      /* Centrer et positionner correctement l'image sans répétition*/
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    }

    html,
    body,
    header,
    .view {
      /* Remplis la totalité de l'écran */
      height: 100%;
      height: 100%;
    }
    /*Texte blanc entouré de noir*/
    @media (min-width: 768px){
      .navbar:not(.top-nav-collapse){
        background: transparent !important;
      }
    }

    @media (min-width: 768px){
      .card{
        margin-right: 80px;
        width: 850px;
        }
      .card:nth-child(2){
        margin-right: 95px;
        width: 850px;
        }
    }
    
    @media (max-width: 768px){
      .tweets, .twitter-timeline{
        display: none;
        visibility: hidden;
        opacity: 0;
      }
    }
    /*Le footer n'a pas de place en-dessous de 1200px*/
    @media (max-width: 1200px){
      .footer{
        display: none;
      }
      body{
        background-image: url("img/cubes.jpg");
        background-color: rgb(24, 23, 31);
      }
    }

    .top-nav-collapse{
      background-color: #78909c !important;
    }
    /*Transparence de la navbar*/
    .navbar:not(.top-nav-collapse){
      background: transparent !important;
    }

    h1{
      letter-spacing: 8px;
    }

    h5{
      letter-spacing: 3px;
    }

    .hr-light{
      border-top: 3px solid #fff;
      width: 80px;
    }

    .container{
      border: 3px dashed #fff;
      border-right: none;
      border-bottom: none;
      color: white;
    }

    .card{
      border: 3px solid red;
      color: black;
      opacity: 0.7;
      margin-left: 40px;
      margin-right: 40px;
      padding: 5px;
    }

    .card:nth-child(2){
      color: black;
      margin-left: 55px;
      margin-right: 55px;
    }

    .card:hover{
      opacity: 1;
      background-image: transparent;
    }
    /*Texte blanc entouré de noir*/
    .stroke{
        color: black;
        text-shadow:
        -1px -1px 0 white,
        1px -1px 0 white,
        -1px 1px 0 white,
        1px 1px 0 white;  
    }

    .glyphicon-copyright-mark, .fa, .copy{
      float: right;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: red;
    }

    .fa{
      float: left;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: black;
    }

    .glyphicon-copyright-mark{
      color: white;
      font-size: 15px;
      padding-top: 15px;
      text-align: center;
    }

    .copyr{
      color: white;
      font-size: 15px;
      padding-top: 5px;
      text-align: center;
    }
  </style>
</head>
<body>
  <header>
  <!-- Mes choix personnels (fixed-top pour que la navbar reste collée en haut -->
  <div class="view">
  <nav class="navbar navbar-expand-lg navbar-inverse bg-inverse navbar-toggleable-lg scrolling-navbar fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" style="color: red" href="index.php">&star;&lt;Nitro~Haven&gt;&star;</a>&nbsp;
        <!-- Création du bouton pour le basculement du menu -->
        <a class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <!-- Le "navbar-toggler-icon" ne s'affichant pas, j'ai rajouté une icône hamburger (Bootstrap) -->
          <span style="float: right; font-size: 25px; padding: 3px; color: red;" class="glyphicon glyphicon-menu-hamburger"></span>
        </a>
      </div>
      <!-- J'ai créé des listes désordonnées pour le style des liens -->
      <ul class="nav navbar-nav collapse navbar-collapse" id="navbarNav">
        <li class="active"><a href="index.php">Accueil</a></li>
        <li><a href="products.php">Produits</a></li>
        <li><a href="gallery.php">Galeries</a></li>
        <li><a href="contact.php">Nous contacter</a></li>
      </ul>
      <hr>
    </div>
  </nav>
  <!-- Alignement de la page et de ses éléments "enfants" -->
  <div class="mask rgba-black-light d-flex justify-content-center align-items-center">
    <!-- Contenu -->
    <div class="container">
      <!-- Ligne -->
      <table>
      <tr>
      <td>
      <div class="row">
        <!-- Colonne et efets spéciaux -->
        <div class="col-md-12 mb-4 white-text text-center">
          <h1 class="h1-reponsive white-text text-uppercase font-weight-bold mb-0 pt-md-5 pt-5 wow fadeInDown" data-wow-delay="0.3s"><strong>Présentation</strong></h1>
          <hr class="hr-light my-4 wow fadeInDown" data-wow-delay="0.4s">
          <h5 class="text-uppercase mb-4 white-text wow fadeInDown" data-wow-delay="0.4s"><strong>Collaboration, Web & Design</strong></h5>
          <a class="btn btn-outline-white wow fadeInDown" data-wow-delay="0.4s" href="https://mondesirm.wordpress.com/">PortFolio WordPress</a>
          <a class="btn btn-outline-white wow fadeInDown" data-wow-delay="0.4s" href="https://www.linkedin.com/in/malik-mondesir/">Page LinkedIn</a>
          <!-- Carte Social -->
          <div class="card card-image" style="background-image: url(https://mdbootstrap.com/img/Photos/Horizontal/Work/4-col/img%20%2814%29.jpg);>
              <!-- Contenu -->
            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
              <div class="stroke">
                <h5 class="pink-text"><i class="glyphicon glyphicon-user"></i> Social</h5>
                <h3 class="card-title pt-2"><strong>Qui nous sommes ?</strong></h3>
                <p style="font-size: 17px">Nous sommes un groupe d"individus aguerris et expérimentés dans la programmation WEB.</p>
                <button style="border-color: blue" class="btn btn-pink"><a href="https://github.com/SunReiAzzy/Nitro-Haven"><i class="glyphicon glyphicon-eye-open"></i> Voir projet Github</a></button>
              </div><br>
            </div>
          </div>
          &nbsp;
          <!-- Carte Offres -->
          <div class="card card-image" style="background-image: url(http://getwallpapers.com/wallpaper/full/c/5/d/688482-large-software-wallpapers-1920x1080-hd-1080p.jpg);">
              <!-- Contenu -->
            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
              <div class="stroke">
                <h5 class="pink-text"><i class="glyphicon glyphicon-euro"></i> Offres</h5>
                <h3 class="card-title pt-2"><strong>Ce que nous proposons ?</strong></h3>
                <p style="font-size: 17px">Afin que nos fidèles followers puissent suivre nos projets, nous vous offrons des abonnements et licences de logiciels NON libres à un bas prix.</p>
                <button style="border-color: blue" class="btn btn-pink"><a href="products.php"><i class="glyphicon glyphicon-hand-right"></i> Accéder aux offres</a></button>
              </div><br>
            </div>
            
          </div><br>
        </div>
      </td>
      <td>
      <a class="twitter-timeline tweets" data-width="340" data-height="500" data-theme="dark" data-link-color="#E81C4F" href="https://twitter.com/TwitterDev?ref_src=twsrc%5Etfw">Tweets by TwitterDev</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
      </td>
      </tr>
      </table>
      </div>
    </div>
  </div>
  </div>
  <div class="footer">
  <a class="navbar-brand fixed-bottom" style="color: black" href="contact.php"><b>Nous Contacter<b></a>&nbsp;
  <a href="https://www.facebook.com/FacebookFrance/" class="fa fa-facebook"></a>
  <a href="https://twitter.com/TwitterDev?ref_src=twsrc%5Etfw" class="fa fa-twitter"></a>
  <a href="https://plus.google.com/+Chrome" class="fa fa-google-plus"></a>
  <span class="glyphicon glyphicon-copyright-mark" style="visibility: hidden;"></span>
  <span class="glyphicon glyphicon-copyright-mark"></span>
  <div class="copy" style="height: 15px;">
    <span class="copyr">Nitro Haven</span>
  </div>
</div>
  </header>
</body>
</html>