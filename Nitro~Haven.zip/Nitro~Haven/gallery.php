<!DOCTYPE html>
<html lang="en">
<head>
  <title>&star;&lt;Nitro~Haven&gt;&star;</title>
  <meta charset="utf-8">
  <link href="https://fonts.googleapis.com/css?family=Bungee+Shade|Caveat|Megrim|Fondamento|Press+Start+2P" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <style>
    /* L'icône toggler restait visible pour n'importe quels dimensions de la fenêtre donc... */
    @media screen and (min-width: 768px){
      .navbar-toggler{
        display: none;
      }
    }
    body, .navbar{
      /* L'une des polices que j'ai importé depuis Google Fonts */
      font-family: "Fondamento", cursive;
      /*Au cas où, le "bg" ne couvre pas tout l'écran*/
      background-color: black;
    }
    .view{
      /* Image du décor */
      background-image: url('img/cubes.gif');
      /* Centrer et positionner correctement l'image sans répétition*/
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    }

    html,
    body,
    header,
    .view {
      /* Remplis la totalité de l'écran */
      height: 100%;
      height: 100%;
    }

    @media (min-width: 768px){
      .navbar:not(.top-nav-collapse){
        background: transparent !important;
      }
    }

    @media (max-width: 768px){
      .footer{
        display: none;
      }
      .fullscreen{
        display: block;
      }
    }

    .top-nav-collapse{
      background-color: #78909c !important;
    }

    .navbar:not(.top-nav-collapse){
      background: transparent !important;
    }

    h1{
      letter-spacing: 8px;
    }

    h5{
      letter-spacing: 3px;
    }

    .hr-light{
      border-top: 3px solid #fff;
      width: 80px;
    }

    .stroke{
        color: white;
        text-shadow:
        -1px -1px 0 black,
        1px -1px 0 black,
        -1px 1px 0 black,
        1px 1px 0 black;  
    }

    .glyphicon-copyright-mark, .fa, .copy{
      float: right;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: red;
    }

    .fa{
      float: left;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: red;
    }

    .glyphicon-copyright-mark{
      color: white;
      font-size: 15px;
      padding-top: 15px;
      text-align: center;
    }

    .copyr{
      color: white;
      font-size: 15px;
      padding-top: 5px;
      text-align: center;
    }

    *{box-sizing: border-box}
    body {font-family: Verdana, sans-serif; margin: 0}
    .mySlides{display: none}
    img{vertical-align: middle;}

    /* Slideshow container */
    .slideshow-container{
      max-width: 1000px;
      position: relative;
      margin: auto;
    }

    /* Next & previous buttons */
    .prev, .next{
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      padding: 16px;
      margin-top: -22px;
      color: white;
      font-weight: bold;
      font-size: 18px;
      transition: 0.6s ease;
      border-radius: 0 3px 3px 0;
      user-select: none;
    }

    /* Position the "next button" to the right */
    .next{
      right: 0;
      border-radius: 3px 0 0 3px;
    }

    /* On hover, add a black background color with a little bit see-through */
    .prev:hover, .next:hover{
      background-color: rgba(0,0,0,0.8);
    }

    /* Caption text */
    .text{
      color: #f2f2f2;
      font-size: 15px;
      padding: 8px 12px;
      position: absolute;
      bottom: 8px;
      width: 100%;
      text-align: center;
    }

    /* Number text (1/3 etc) */
    .numbertext{
      color: #f2f2f2;
      font-size: 12px;
      padding: 8px 12px;
      position: absolute;
      top: 0;
    }

    /* The dots/bullets/indicators */
    .dot{
      cursor: pointer;
      height: 15px;
      width: 15px;
      margin: 0 2px;
      background-color: #bbb;
      border-radius: 50%;
      display: inline-block;
      transition: background-color 0.6s ease;
    }

    .active, .dot:hover{
      background-color: #717171;
    }

    /* Fading animation */
    .fade{
      opacity: 1;
      animation-name: fade;
      animation-duration: 3s;
    }

    img{
      width: 640px;
      height: 480px;
      align-self: center;
      text-align: center;
      padding-top: 20px;
    }

    @keyframes fade {
      from {opacity: .3}
      to {opacity: 1}
    }

    /* On smaller screens, decrease text size */
    @media only screen and (max-width: 300px){
      .prev, .next,.text {font-size: 11px}
    }
  </style>
</head>
<body>
  <header>
  <!-- Mes choix personnels (fixed-top pour que la navbar reste collée en haut -->
  <div class="view">
  <nav class="navbar navbar-expand-lg navbar-inverse bg-inverse navbar-toggleable-lg scrolling-navbar fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" style="color: red" href="index.php">&star;&lt;Nitro~Haven&gt;&star;</a>&nbsp;
        <!-- Création du bouton pour le basculement du menu -->
        <a class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <!-- Le "navbar-toggler-icon" ne s'affichant pas, j'ai rajouté une icône hamburger (Bootstrap) -->
          <span style="float: right; font-size: 25px; padding: 3px; color: red;" class="glyphicon glyphicon-menu-hamburger"></span>
        </a>
      </div>
      <!-- J'ai créé des listes désordonnées pour le style des liens -->
      <ul class="nav navbar-nav collapse navbar-collapse" id="navbarNav">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="products.php">Produits</a></li>
        <li class="active"><a href="gallery.php">Galeries</a></li>
        <li><a href="contact.php">Nous contacter</a></li>
      </ul>
      <hr>
    </div>
  </nav>
    <!-- Alignement de la page et de ses éléments "enfants" -->
    <div class="mask rgba-black-light d-flex justify-content-center align-items-center">
      <!-- Contenu -->
      <div class="container">
        <div id="gallery" class="slideshow-container" style="width: auto; height: auto;">

        <div class="mySlides fade">
          <div class="numbertext">1 / 5</div>
          <img src="img/slide1.jpg" style="width:100%">
          <div class="text stroke">Mirrored Lake</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">2 / 5</div>
          <img src="img/slide2.jpg" style="width:100%">
          <div class="text stroke">Moon Lake Swan Diamond</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">3 / 5</div>
          <img src="img/slide3.jpg" style="width:100%">
          <div class="text stroke">Crimson LakeSide</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">4 / 5</div>
          <img src="img/slide4.jpg" style="width:100%">
          <div class="text stroke">Sunset Evening Watercolour Painting</div>
        </div>

        <div class="mySlides fade">
          <div class="numbertext">5 / 5</div>
          <img src="img/slide5.jpg" style="width:100%">
          <div class="text stroke">Lewanda Landscape</div>
        </div>

        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>

        </div>
        <br>

        <div style="text-align:center">
          <span class="dot" onclick="currentSlide(1)"></span> 
          <span class="dot" onclick="currentSlide(2)"></span> 
          <span class="dot" onclick="currentSlide(3)"></span>
          <span class="dot" onclick="currentSlide(4)"></span>
          <span class="dot" onclick="currentSlide(5)"></span>
          <div id="fullscreen" style="cursor: pointer;"><a style="color: red;" onclick="openFullscreen()">Plein Écran</a></div>
        </div>
        
        <div class="footer">
          <a class="navbar-brand fixed-bottom" style="color: red" href="contact.php">Nous Contacter</a>&nbsp;
          <a href="https://www.facebook.com/FacebookFrance/" class="fa fa-facebook"></a>
          <a href="https://twitter.com/TwitterDev?ref_src=twsrc%5Etfw" class="fa fa-twitter"></a>
          <a href="https://plus.google.com/+Chrome" class="fa fa-google-plus"></a>
          <span class="glyphicon glyphicon-copyright-mark" style="visibility: hidden;"></span>
          <span class="glyphicon glyphicon-copyright-mark"></span>
          <div class="copy" style="height: 15px;">
            <span class="copyr">Nitro Haven</span>
          </div>
        </div>
        <script>
          var slideIndex = 1;
          showSlides(slideIndex);
  
          function plusSlides(n) {
            showSlides(slideIndex += n);
          }
  
          function currentSlide(n) {
            showSlides(slideIndex = n);
          }
  
          function showSlides(n) {
            var i;
            var slides = document.getElementsByClassName("mySlides");
            var dots = document.getElementsByClassName("dot");
            if (n > slides.length) {slideIndex = 1}    
            if (n < 1) {slideIndex = slides.length}
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";  
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex-1].style.display = "block";  
            dots[slideIndex-1].className += " active";
          }
        </script>
      </div>
    </div>
  </div>
  </header>
</body>
</html>
<script>
  /* Get the element you want displayed in fullscreen mode (a video in this example): */
  var elem = document.getElementById("gallery"); 
  /* When the openFullscreen() function is executed, open the video in fullscreen.
  Note that we must include prefixes for different browsers, as they don't support the requestFullscreen method yet */
  function openFullscreen() {
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { /* Firefox */
      elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { /* IE/Edge */
      elem.msRequestFullscreen();
    }
  }
</script>