<!DOCTYPE HTML>
<html>
<head>
  <title>&star;&lt;Nitro Haven&gt;&star;</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script
  src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</head>
<body style="border-style: 1px black">
    <?php include "headers/c_header.php"?>
    <hr style="width: 100%; height: 10px">
    <div id="twitter-timeline">
      <a class="twitter-timeline" href="https://twitter.com/TwitterDev?ref_src=twsrc%5Etfw">Tweets by TwitterDev</a>
    </div>
    <div id="page">
      <div class="LI-profile-badge"  data-version="v1" data-size="medium" data-locale="fr_FR" data-type="horizontal" data-theme="dark" data-vanity="malik-mondesir"><a class="LI-simple-link" href='https://fr.linkedin.com/in/malik-mondesir?trk=profile-badge'>Malik MONDESIR</a></div>
    </div>
    <hr style="width: 100%; height: 10px">
</body>
</html>
<?php include "headers/footer.php"?>