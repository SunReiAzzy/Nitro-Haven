<!DOCTYPE html>
<html lang="en">
<head>
  <title>&star;&lt;Nitro~Haven&gt;&star;</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Chargement des feuilles de styles depuis des librairies externes de styles, d'icônes et de polices-->
  <link href="https://fonts.googleapis.com/css?family=Bungee+Shade|Caveat|Megrim|Fondamento|Press+Start+2P" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
  <script type="text/javascript" src="https://platform.linkedin.com/badges/js/profile.js" async defer></script>
  <style>
    /* L'icône toggler restait visible pour n'importe quels dimensions de la fenêtre donc... */
    @media screen and (min-width: 768px){
      .navbar-toggler{
        display: none;
      }
    }
    
    body{
      /* L'une des polices que j'ai importé depuis Google Fonts */
      font-family: "Fondamento", cursive;
      /*Au cas où, le "bg" ne couvre pas tout l'écran*/
      background-color: black;
    }
    .view{
      /* Image du décor */
      background-image: url('img/cubes.gif');
      /* Centrer et positionner correctement l'image sans répétition*/
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    }

    html,
    body,
    header,
    .view {
      /* Remplis la totalité de l'écran */
      height: 100%;
      height: 100%;
    }
    /*Texte blanc entouré de noir*/
    @media (min-width: 768px){
      .navbar:not(.top-nav-collapse){
        background: transparent !important;
      }
    }

    /*Le footer n'a pas de place en-dessous de 1200px*/
    @media (max-width: 1200px){
      .footer{
        display: none;
      }
    }

    .top-nav-collapse{
      background-color: #78909c !important;
    }
    /*Transparence de la navbar*/
    .navbar:not(.top-nav-collapse){
      background: transparent !important;
    }

    h1{
      letter-spacing: 8px;
    }

    h5{
      letter-spacing: 3px;
    }

    .hr-light{
      border-top: 3px solid #fff;
      width: 80px;
    }

    .container{
      background: -webkit-linear-gradient(left, blue, #ff0000);
      border-radius: 30px;
      width: 1000px;
    }

    /*Texte blanc entouré de noir*/
    .stroke{
        color: black;
        text-shadow:
        -1px -1px 0 white,
        1px -1px 0 white,
        -1px 1px 0 white,
        1px 1px 0 white;  
    }

    .glyphicon-copyright-mark, .fa, .copy{
      float: right;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: red;
    }

    .fa{
      float: left;
      font-size: 25px;
      padding: 3px;
      padding-top: 10px;
      color: red;
    }

    .glyphicon-copyright-mark{
      color: white;
      font-size: 15px;
      padding-top: 15px;
      text-align: center;
    }

    .copyr{
      color: white;
      font-size: 15px;
      padding-top: 5px;
      text-align: center;
    }

    .contact-form{
        background: #fff;
        margin-top: 10%;
        margin-bottom: 5%;
        width: 800px;
    }
    .contact-form .form-control{
        border-radius:1rem;
    }
    .contact-image{
        text-align: center;
    }
    .contact-image img{
        width: 11%;
        margin-top: -3%;
        border-radius: 6rem;
        border: 1px dashed black;
    }
    .contact-form form{
        padding: 14%;
    }
    .contact-form form .row{
        margin-bottom: -7%;
    }
    .contact-form h3{
        margin-bottom: 8%;
        margin-top: -10%;
        text-align: center;
        color: #0062cc;
    }
    .contact-form .btnContact {
        width: 50%;
        border: none;
        border-radius: 1rem;
        padding: 1.5%;
        background: #dc3545;
        font-weight: 600;
        color: #fff;
        cursor: pointer;
    }
    .btnContactSubmit
    {
        width: 50%;
        border-radius: 1rem;
        padding: 1.5%;
        color: #fff;
        background-color: #0062cc;
        border: none;
        cursor: pointer;
    }
  </style>
</head>
<body>
  <header>
  <!-- Mes choix personnels (fixed-top pour que la navbar reste collée en haut -->
  <div class="view">
  <nav class="navbar navbar-expand-lg navbar-inverse bg-inverse navbar-toggleable-lg scrolling-navbar fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" style="color: red" href="index.php">&star;&lt;Nitro~Haven&gt;&star;</a>&nbsp;
        <!-- Création du bouton pour le basculement du menu -->
        <a class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <!-- Le "navbar-toggler-icon" ne s'affichant pas, j'ai rajouté une icône hamburger (Bootstrap) -->
          <span style="float: right; font-size: 25px; padding: 3px; color: red;" class="glyphicon glyphicon-menu-hamburger"></span>
        </a>
      </div>
      <!-- J'ai créé des listes désordonnées pour le style des liens -->
      <ul class="nav navbar-nav collapse navbar-collapse" id="navbarNav">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="products.php">Produits</a></li>
        <li><a href="gallery.php">Galeries</a></li>
        <li class="active"><a href="contact.php">Nous contacter</a></li>
      </ul>
      <hr>
    </div>
  </nav>
    <!-- Alignement de la page et de ses éléments "enfants" -->
    <div class="mask rgba-black-light d-flex justify-content-center align-items-center">
      <!-- Contenu -->
      <div class="container">
        <div class="container contact-form">
          <div class="contact-image">
              <img src="img/show.png" alt="user"/>
          </div>
          <form role="form" method="post" id="reused_form" action="mailto:malikmondesir@gmail.com?subject=Feedback?mailto:example@tutorialspark.com?subject=Feedback?body=(Votre message)">
            <h3>Laissez-nous un commentaire !</h3>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                    <input type="text" name="nom" class="form-control" placeholder="Nom *" required autofocus>
                </div>
                <div class="form-group">
                    <input type="text" name="prenom" class="form-control" placeholder="Prénom *" required>
                </div>
                <div class="form-group">
                    <input type="email" name="email" class="form-control" placeholder="Email *" required>
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" class="btnContact" value="Envoyer" onclick="Succes()">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <textarea name="msg" class="form-control" placeholder="Ton commentaire *" style="width: 100%; height: 150px;" maxlength="500" required></textarea>
                </div>
                  <!-- <div class="LI-profile-badge"  data-version="v1" data-size="medium" data-locale="fr_FR" data-type="horizontal" data-theme="dark" data-vanity="malik-mondesir"><a class="LI-simple-link" href='https://fr.linkedin.com/in/malik-mondesir?trk=profile-badge'>Malik MONDESIR</a></div> -->
              </div>
            </div>
          </form>
          <div id="success_message" style="width:100%; height:30px; display:none;">
            <h3>Succès!</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
  </nav>
  <div class="tech" style="background-image: url("tech.jpg");">
  <div class="footer">
    <a class="navbar-brand fixed-bottom" style="color: red" href="contact.php">Nous Contacter</a>&nbsp;
    <a href="https://www.facebook.com/FacebookFrance/" class="fa fa-facebook"></a>
    <a href="https://twitter.com/TwitterDev?ref_src=twsrc%5Etfw" class="fa fa-twitter"></a>
    <a href="https://plus.google.com/+Chrome" class="fa fa-google-plus"></a>
    <span class="glyphicon glyphicon-copyright-mark" style="visibility: hidden;"></span>
    <span class="glyphicon glyphicon-copyright-mark"></span>
    <div class="copy" style="height: 15px;">
      <span class="copyr">Nitro Haven</span>
    </div>
  </div>
  </header>
</body>
</html>
<script>
  function Succes() {
    document.getElementById('succes_message').display = 'block';
  }
</script>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST')
  echo "<script>
          document.getElementById('succes_message').display = 'block';
        </script>"
?>