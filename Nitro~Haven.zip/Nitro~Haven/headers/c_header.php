<nav class="navbar navbar-inverse navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand header" href="index.php">&star;&lt;Nitro~Haven&gt;&star;</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="index.php">Accueil</a>
      <a class="nav-item nav-link" href="products.php">Produits</a>
      <a class="nav-item nav-link" href="gallery.php">Galerie</a>
      <a class="nav-item nav-link active" href="contact.php">Contact<span class="sr-only">(current)</span></a>
      </li>
    </div>
  </div>
</nav>