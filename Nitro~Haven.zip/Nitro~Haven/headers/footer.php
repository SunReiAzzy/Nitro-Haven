<link href="https://fonts.googleapis.com/css?family=Bungee+Shade|Caveat|Megrim|Fondamento|Press+Start+2P" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>


<script type="text/javascript" src="https://platform.linkedin.com/badges/js/profile.js" async defer></script>
<style>
	.fa {
	  padding: 20px;
	  font-size: 30px;
	  width: 30px;
	  text-align: center;
	  text-decoration: none;
	  margin: 5px 2px;
	  border-radius: 50%;
	}

	.fa:hover {
	    opacity: 0.7;
	}

	.fa-facebook {
	  background: #3B5998;
	  color: white;
	}

	.fa-twitter {
	  background: #55ACEE;
	  color: white;
	}

	.fa-google {
	  background: #dd4b39;
	  color: white;
	}

	.fa-linkedin {
	  background: #007bb5;
	  color: white;
	}

	.fa-youtube {
	  background: #bb0000;
	  color: white;
	}

	.fa-instagram {
	  background: #125688;
	  color: white;
	}

	.fa-pinterest {
	  background: #cb2027;
	  color: white;
	}

	.fa-snapchat-ghost {
	  background: #fffc00;
	  color: white;
	  text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;
	}

	.fa-skype {
	  background: #00aff0;
	  color: white;
	}

	.fa-android {
	  background: #a4c639;
	  color: white;
	}
	body, .navbar{
      font-family: 'Fondamento', cursive;
      font-size: 10px;
    }
	.footer{
      font-family: 'Fondamento', cursive;
      font-size: 10px;
    }
</style>


	<div class="LI-profile-badge"  data-version="v1" data-size="medium" data-locale="fr_FR" data-type="horizontal" data-theme="dark" data-vanity="malik-mondesir"><a class="LI-simple-link" href='https://fr.linkedin.com/in/malik-mondesir?trk=profile-badge'>Malik MONDESIR</a></div>
	<a href="https://www.facebook.com" class="fa fa-facebook"></a>
	<a href="https://www.facebook.com" class="fa fa-twitter"></a>
	<a href="https://www.facebook.com" class="fa fa-google"></a>
	<a href="https://fr.linkedin.com/in/malik-mondesir?trk=profile-badge" class="fa fa-linkedin"></a>
	<a href="https://www.youtube.com" class="fa fa-youtube"></a>
	<a href="https://www.facebook.com" class="fa fa-android"></a>
</nav>