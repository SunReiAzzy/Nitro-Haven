<!DOCTYPE html>
<html lang="en">
<head>
  <title>&star;&lt;Nitro~Haven&gt;&star;</title>
  <meta charset="utf-8">
  <!-- Chargement des feuilles de styles depuis des librairies externes -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
  <style>
    /* L'icône toggler restait visible pour n'importe quels dimensions de la fenêtre donc... */
    @media screen and (min-width: 768px){
      .navbar-toggler{
        display: none;
      }
    }
    /* L'une des polices que j'ai importé depuis Google Fonts */
    body{
      font-family: "", cursive;
    }
    .view{
      /* Image du décor */
      background-image: url('img/cubes.gif');
      /* Centrer et positionner correctement l'image sans répétition*/
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    }

    html,
    body,
    header,
    .view {
      /* Remplis la totalité de l'écran */
      height: 100%;
      height: 100%;
    }
    /*Texte blanc entouré de noir*/
    @media (min-width: 768px){
      .navbar:not(.top-nav-collapse){
        background: transparent !important;
      }
    }

    .top-nav-collapse{
      background-color: #78909c !important;
    }
    /*Transparence de la navbar*/
    .navbar:not(.top-nav-collapse){
      background: transparent !important;
    }

    h1{
      letter-spacing: 8px;
    }

    h5{
      letter-spacing: 3px;
    }

    .hr-light{
      border-top: 3px solid #fff;
      width: 80px;
    }

    .container{
      border: 3px solid #fff;
      color: white;
    }

    .card{
      border: 3px solid red;
      color: black;
      opacity: 0.7;
    }

    .card:hover{
      opacity: 1;
      background-image: transparent;
    }
    /*Texte blanc entouré de noir*/
    .stroke{
        color: black;
        text-shadow:
        -1px -1px 0 white,
        1px -1px 0 white,
        -1px 1px 0 white,
        1px 1px 0 white;  
    }
  </style>
</head>
<body>
  <header>
  <!-- Mes choix personnels (fixed-top pour que la navbar reste collée en haut -->
  <div class="view">
  <nav class="navbar navbar-expand-lg navbar-inverse bg-inverse navbar-toggleable-lg scrolling-navbar fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" style="color: red" href="index.php">&star;&lt;Nitro~Haven&gt;&star;</a>&nbsp;
        <!-- Création du bouton pour le basculement du menu -->
        <a class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <!-- Le "navbar-toggler-icon" ne s'affichant pas, j'ai rajouté une icône hamburger (Bootstrap) -->
          <span style="float: right; font-size: 25px; padding: 3px; color: red;" class="glyphicon glyphicon-menu-hamburger"></span>
        </a>
      </div>
      <!-- J'ai créé des listes désordonnées pour le style des liens -->
      <ul class="nav navbar-nav collapse navbar-collapse" id="navbarNav">
        <li class="active"><a href="index.php">Accueil</a></li>
        <li><a href="products.php">Produits</a></li>
        <li><a href="gallery.php">Galeries</a></li>
        <li><a href="contact.php">Nous contacter</a></li>
      </ul>
      <hr>
    </div>
  </nav>
    <!-- Alignement de la page et de ses éléments "enfants" -->
    <div class="mask rgba-black-light d-flex justify-content-center align-items-center">
      <!-- Contenu -->
      <div class="container">
        <?php include gallery.php?>
      </div>
    </div>
  </div>
  </header>
</body>
</html>